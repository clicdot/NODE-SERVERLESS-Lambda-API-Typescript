module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(1);


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lambda_api_1 = __webpack_require__(2);
const routes_1 = __webpack_require__(3);
const api = lambda_api_1.default({});
api.register(routes_1.Routes.employees, { prefix: '/v1' });
api.register(routes_1.Routes.routes, { prefix: '/v1' });
api.register(routes_1.Routes.customerOrders, { prefix: '/v1' });
api.get('/test', async (req, res) => {
    return res.status(200).json({ message: 'Hello World' });
});
api.get('/test2', async (req, res) => {
    return res.status(200).json({ message: 'Hello World 2' });
});
api.options('/*', (req, res) => {
    res.send({ error: 404 });
});
const handler = (event, context, callback) => {
    api.run(event, context, callback);
};
exports.handler = handler;


/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("lambda-api");

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.Routes = void 0;
const employees_1 = __webpack_require__(4);
const routes_1 = __webpack_require__(15);
const customer_orders_1 = __webpack_require__(16);
exports.Routes = {
    employees: employees_1.employees,
    routes: routes_1.routes,
    customerOrders: customer_orders_1.customerOrders
};


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.employees = void 0;
const handlers_1 = __webpack_require__(5);
exports.employees = (api, options) => {
    api.get('/employees', handlers_1.handlersFactory.employeesHandler.GET);
    api.get('/employees/:id', handlers_1.handlersFactory.employeesHandler.GETBYID);
};


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handlersFactory = void 0;
const employees_1 = __webpack_require__(6);
exports.handlersFactory = {
    employeesHandler: employees_1.employeesHandler
};


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.employeesHandler = void 0;
const put_1 = __webpack_require__(7);
const post_1 = __webpack_require__(8);
const delete_1 = __webpack_require__(9);
const get_1 = __webpack_require__(10);
exports.employeesHandler = {
    GET: get_1.GET,
    GETBYID: get_1.GETBYID,
    PUT: put_1.PUT,
    POST: post_1.POST,
    DELETE: delete_1.DELETE
};


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.PUT = void 0;
exports.PUT = async (req, res, next) => {
    return ['hello'];
};


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
exports.POST = async (req, res, next) => {
    return ['hello'];
};


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.DELETE = void 0;
exports.DELETE = async (req, res, next) => {
    return ['hello'];
};


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.GETBYID = exports.GET = void 0;
const services_1 = __webpack_require__(11);
exports.GET = async (req, res, next) => {
    const SVC = new services_1.servicesFactory.EmployeesService();
    return SVC.find();
};
exports.GETBYID = async (req, res, next) => {
    const { id } = req.params;
    const SVC = new services_1.servicesFactory.EmployeesService();
    console.log(id);
    return SVC.findById(id);
};


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.servicesFactory = void 0;
const employees_1 = __webpack_require__(12);
exports.servicesFactory = {
    EmployeesService: employees_1.EmployeesService
};


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.EmployeesService = void 0;
const index_1 = __webpack_require__(13);
class EmployeesService {
    constructor() {
        this.tablename = 'wm-ocs-dispatcher-dev';
        this.ddb = new index_1.DynamodbService();
    }
    find() {
        return this.ddb.scan(this.tablename).catch(e => {
            throw new Error(e.message);
        });
    }
    findById(id) {
        return this.ddb.get(this.tablename, {
            'EMPLOYEEOBJID': unescape(id)
        }).catch(e => {
            console.log(e);
            throw new Error(e.message);
        });
    }
}
exports.EmployeesService = EmployeesService;


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamodbService = void 0;
const AWS = __webpack_require__(14);
class DynamodbService {
    constructor() {
        this.AWS = AWS;
        this.AWS.config.update({ region: 'us-east-1' });
        this.AWS.config.credentials = new this.AWS.SharedIniFileCredentials({ profile: 'serverless' });
        this.docClient = new this.AWS.DynamoDB.DocumentClient();
    }
    scan(table) {
        const params = {
            TableName: table
        };
        return new Promise((resolve, reject) => {
            this.docClient.scan(params, (err, data) => {
                if (err) {
                    console.log(err);
                    reject(err);
                }
                else {
                    resolve(data.Items);
                }
            });
        });
    }
    query(table, projection, conditionExpression, attributeNames, attributeValues) {
        const params = {
            TableName: table,
            ProjectionExpression: projection,
            KeyConditionExpression: conditionExpression,
            ExpressionAttributeNames: attributeNames,
            ExpressionAttributeValues: attributeValues
        };
        return new Promise((resolve, reject) => {
            this.docClient.query(params, (err, data) => {
                if (err) {
                    console.log(err);
                    reject(err);
                }
                else {
                    resolve(data.Items);
                }
            });
        });
    }
    get(table, keys) {
        const params = {
            TableName: table,
            Key: keys
        };
        console.log(params);
        return new Promise((resolve, reject) => {
            this.docClient.get(params, (err, data) => {
                if (err) {
                    reject(err);
                }
                else {
                    console.log(data);
                    resolve(data);
                }
            });
        });
    }
}
exports.DynamodbService = DynamodbService;


/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.routes = void 0;
exports.routes = (api, options) => {
    api.get('/routes', async (req, res) => {
        return res.status(200).json({ message: 'Hello World - Routes' });
    });
};


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.customerOrders = void 0;
exports.customerOrders = (api, options) => {
    api.get('/customer-orders', async (req, res) => {
        return res.status(200).json({ message: 'Hello World - Customer Orders' });
    });
};


/***/ })
/******/ ]);
//# sourceMappingURL=app.js.map